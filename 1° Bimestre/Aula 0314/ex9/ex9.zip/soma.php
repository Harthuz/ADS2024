<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Soma dos Ímpares</title>
</head>
<body>
    <?php
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        
        if($num1 % 2 == 0){
            $num1 += 1;
            $valor = $num1;

            while($valor <= $num2){
                echo $valor .'<br>';
                $soma += $valor;
                $valor += 2;
            }
            echo $soma;
        }else{
            $valor = $num1;
            while($valor <= $num2){
                echo $valor .'<br>';
                $soma += $valor;
                $valor += 2;
            }
        }
    ?>
</body>
</html>